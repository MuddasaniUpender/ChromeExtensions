
chrome.tabs.query({'active': true, 
				'windowId': chrome.windows.WINDOW_ID_CURRENT},
   function(tabs){
          var tab = tabs[0];
  var url = new URL(tab.url)
  var domain = url.hostname
  document.write(tab);
  document.write(url+ "<br>");
  document.write(domain)
   }
);


